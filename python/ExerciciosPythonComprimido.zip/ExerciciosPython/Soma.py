n1 = int(input('digite um valor'))
n2 = int(input('digite outro valor'))
s = n1 + n2
print('a soma entre {}, e {} é: {}'.format(n1, n2, s))