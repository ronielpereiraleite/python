n = int(input('digite um valor para a tabuada: '))

print('{} x 0 = {}\t\t{} x 1 = {}\n{} x 2 = {}\t\t{} x 3 = {}\n{} x 4 = {}\t\t{} x 5 = {}\n{} x 6 = {}\t\t{} x 7 = {}\n{} x 8 = {}\t\t'
      '{} x 9 = {}\n{} x 10 = {}'.format(n,n*0,n,n*1,n,n*2,n,n*3,n,n*4,n,n*5,n,n*6,n,n*7,n,n*8,n,n*9,n,n*10))