n = float(input('qual o valor do produto? '))

print('esse produto está saindo a R$ {:.2f} com o desconto de  {}'.format(n - (n * .05),n * .05)) #não pode esquecer de colocar o zero depois da virgula se for numeros menores que 10

#print('o valor a ser pago e {:.2f} /n você teve o desconto de 5% equivalente a {:.2f}'.format(n - (n * 5 /100),n * 5 /100))


