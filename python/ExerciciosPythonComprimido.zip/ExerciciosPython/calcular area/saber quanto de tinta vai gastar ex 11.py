a = float(input('digite a altuda da parede: '))
l = float(input('digite largura'))
mq = 2
mqt = a * l

print('vai gastar {} litros de tinta nesta parede'.format(mqt/mq))

# parei na aula 7 34.10 minutos