nome = input("digite seu nome: ")
print('praser em te conhecer, {} !!!  (´-´)'.format(nome))

#usando o .format() ele faz divisão do que se escreve antes e depois das {}