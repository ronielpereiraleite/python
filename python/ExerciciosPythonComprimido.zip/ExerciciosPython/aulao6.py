n1 = int(input('digite um numero'))
n2 = int(input('digiote outro numero'))
s = n1 + n2

print('a soma de {} e de {} é {}'.format(n1, n2, s))

# usando a função .format()  as chaves representão as variaveis entre as aspas