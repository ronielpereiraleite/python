num = int(input('digite um numero'))

d = int(num * 2)
t = int(num * 3)
r = int(num **(1/2))  #SE FOSSE RAIZ CUBICA USARIA (NUM **(1/3))

print('\ndobro {}\n triplo \t{:-^8}\n raiz quadrada {:-^8}'.format(d,t,r))

# PAREI NA AULA 7 NO EXERCICIO 7  NO TEMPO 32:20