num = int(input('digite um valor: '))

a = int(num - 1)
num = num + 1
print('antecessor {}\n sucessor {}'.format(a,num))