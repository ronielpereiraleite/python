import math       # importa todas as bibliotecas de de math (funções matematicas)

n = int(input('digite um numero\n\t\t'))
raiz = math.sqrt(n) #descobre a raiz de n
print('\n\t\t\ta raiz de {} é {}'.format(n, raiz))


#from math import sqrt   # importa somente a função desejada de uma biblioteca
#
#n = int(input('digite um numero\n\t\t'))
#raiz = sqrt(n) #descobre a raiz de n
#print('\n\t\t\ta raiz de {} é {}'.format(n, raiz))