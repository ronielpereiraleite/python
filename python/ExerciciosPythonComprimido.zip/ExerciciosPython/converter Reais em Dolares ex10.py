n = float(input('qual é o valor a ser convertido? '))

print('{} US$'.format(n * 5.27))

# deu problema na minha porcentagem